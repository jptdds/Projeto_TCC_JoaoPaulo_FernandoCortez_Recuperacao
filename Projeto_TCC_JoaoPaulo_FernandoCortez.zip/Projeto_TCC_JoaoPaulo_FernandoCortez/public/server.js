require('dotenv').config();
const express = require('express');
const mysql = require('mysql2/promise');
const jwt = require('jsonwebtoken');
const bcrypt = require('bcrypt');
const cors = require('cors');

const app = express();

app.use(cors());
app.use(express.json());

// ========================
// CONFIG BANCO
// ========================
const pool = mysql.createPool({
  host: process.env.DB_HOST,
  user: process.env.DB_USER,
  password: process.env.DB_PASSWORD,
  database: process.env.DB_NAME,
  waitForConnections: true,
  connectionLimit: 10
});

async function query(sql, params = []) {
  const [rows] = await pool.execute(sql, params);
  return rows;
}

// ========================
// MIDDLEWARE AUTH
// ========================
function requireAuth(req, res, next) {
  const authHeader = req.headers.authorization;

  if (!authHeader || !authHeader.startsWith('Bearer ')) {
    return res.status(401).json({ error: 'Token não fornecido' });
  }

  const token = authHeader.split(' ')[1];
  console.log("ID vindo do token:", req.userId);

  try {
    const decoded = jwt.verify(token, process.env.JWT_SECRET);
    req.userId = decoded.id;
    next();
  } catch (err) {
    console.error("Erro JWT:", err.message);
    return res.status(401).json({ error: 'Token inválido ou expirado' });
  }
}

// ========================
// LOGIN
// ========================
app.post('/api/login', async (req, res) => {
  try {
    const { email, password } = req.body;

    const users = await query(
      'SELECT * FROM users WHERE email = ? AND is_active = 1',
      [email]
    );

    if (users.length === 0) {
      return res.status(401).json({ error: 'Usuário não encontrado ou inativo' });
    }

    const user = users[0];

    const validPassword = await bcrypt.compare(password, user.password);

    if (!validPassword) {
      return res.status(401).json({ error: 'Senha incorreta' });
    }

    const token = jwt.sign(
      { id: user.id },
      process.env.JWT_SECRET,
      { expiresIn: '8h' }
    );

    res.json({ token });

  } catch (error) {
    console.error("Erro no login:", error);
    res.status(500).json({ error: 'Erro interno no login' });
  }
});

// ========================
// LISTAR MATÉRIAS-PRIMAS
// ========================
app.get('/api/raw-materials', requireAuth, async (req, res) => {
  try {
    const materials = await query(
      'SELECT * FROM raw_materials WHERE created_by = ? AND is_active = 1',
      [req.userId]
    );

    res.json(materials);

  } catch (error) {
    console.error("Erro ao listar:", error);
    res.status(500).json({ error: 'Erro ao buscar matérias-primas' });
  }
});

// ========================
// CRIAR MATÉRIA-PRIMA
// ========================
app.post('/api/raw-materials', requireAuth, async (req, res) => {
  try {
    let { name, category, unit, minimum_stock, maximum_stock, unit_cost } = req.body;

    if (!name || !category || !unit) {
      return res.status(400).json({ error: 'Campos obrigatórios faltando' });
    }

    minimum_stock = Number(minimum_stock) || 0;
    maximum_stock = Number(maximum_stock) || 0;
    unit_cost = Number(unit_cost) || 0;

    if (minimum_stock > maximum_stock) {
      return res.status(400).json({ error: 'Estoque mínimo maior que máximo' });
    }

    const result = await pool.execute(
      `INSERT INTO raw_materials
      (name, category, unit, current_stock, minimum_stock, maximum_stock, unit_cost, is_active, created_by)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)`,
      [
        name,
        category,
        unit,
        0,
        minimum_stock,
        maximum_stock,
        unit_cost,
        1,
        req.userId
      ]
    );

    res.status(201).json({
      success: true,
      id: result[0].insertId
    });

  } catch (error) {
    console.error("Erro ao criar matéria-prima:", error);
    res.status(500).json({ error: error.message });
  }
});

// ========================
// ATUALIZAR MATÉRIA-PRIMA
// ========================
app.put('/api/raw-materials/:id', requireAuth, async (req, res) => {
  try {
    const { id } = req.params;
    let { name, category, unit, minimum_stock, maximum_stock, unit_cost } = req.body;

    minimum_stock = Number(minimum_stock) || 0;
    maximum_stock = Number(maximum_stock) || 0;
    unit_cost = Number(unit_cost) || 0;

    await pool.execute(
      `UPDATE raw_materials
       SET name=?, category=?, unit=?, minimum_stock=?, maximum_stock=?, unit_cost=?
       WHERE id=? AND created_by=?`,
      [
        name,
        category,
        unit,
        minimum_stock,
        maximum_stock,
        unit_cost,
        id,
        req.userId
      ]
    );

    res.json({ success: true });

  } catch (error) {
    console.error("Erro ao atualizar:", error);
    res.status(500).json({ error: error.message });
  }
});

// ========================
// DELETAR (SOFT DELETE)
// ========================
app.delete('/api/raw-materials/:id', requireAuth, async (req, res) => {
  try {
    const { id } = req.params;

    await pool.execute(
      `UPDATE raw_materials SET is_active = 0 WHERE id = ? AND created_by = ?`,
      [id, req.userId]
    );

    res.json({ success: true });

  } catch (error) {
    console.error("Erro ao deletar:", error);
    res.status(500).json({ error: error.message });
  }
});

// ========================
const PORT = process.env.PORT || 3000;

app.listen(PORT, () => {
  console.log(`Servidor rodando na porta ${PORT}`);
});
const bcrypt = require('bcrypt');
bcrypt.hash('123456', 10).then(console.log);
