# 📊 Como Usar o Script SQL com Dados Completos

## ⚡ Resumo

O arquivo `populate-database.sql` contém **TODOS** os dados prontos para rodar:
- ✅ 5 usuários
- ✅ 7 fornecedores
- ✅ 20 matérias-primas
- ✅ 20 entradas de estoque
- ✅ 25 movimentações
- ✅ 5 alertas

---

## 🚀 Como Usar (3 Passos)

### 1️⃣ Criar o Banco de Dados

```bash
mysql -u root -p -e "CREATE DATABASE agroindustria_db CHARACTER SET utf8mb4;"
```

(Digite sua senha quando pedir)

### 2️⃣ Executar o Script SQL

```bash
mysql -u root -p agroindustria_db < populate-database.sql
```

(Digite sua senha quando pedir)

### 3️⃣ Pronto! Dados Carregados

O banco agora tem todos os dados. Inicie o servidor:

```bash
npm install
npm start
```

Acesse: **http://localhost:3000**

---

## 🔐 Credenciais de Teste

Todos os usuários têm a senha padrão (vazia em SHA256):

| Usuário | Email | Senha | Perfil |
|---------|-------|-------|--------|
| admin | admin@agroindustria.com | (vazia) | Admin |
| gerente | gerente@agroindustria.com | (vazia) | Admin |
| operador1 | operador1@agroindustria.com | (vazia) | Operador |
| operador2 | operador2@agroindustria.com | (vazia) | Operador |
| analista | analista@agroindustria.com | (vazia) | Operador |

---

## 📋 Dados Inclusos

### Usuários (5)
- Admin (gerenciador do sistema)
- Gerente (acesso total)
- 2 Operadores (acesso limitado)
- 1 Analista (acesso a relatórios)

### Fornecedores (7)
- Agrícola Brasil Ltda (SP)
- Grãos do Centro (MG)
- Sementes Premium (SC)
- Fertilizantes Globais (CE)
- Insumos Agrícolas Sul (RS)
- Produtos Agrícolas Norte (AM)
- Agrotech Inovação (MG)

### Matérias-Primas (20)
**Grãos (6):**
- Milho Amarelo
- Soja
- Trigo
- Arroz
- Milho Branco
- Sorgo

**Fertilizantes (5):**
- Nitrogênio (N)
- Fósforo (P)
- Potássio (K)
- Ureia
- Superfosfato Simples

**Sementes (4):**
- Sementes de Milho Híbrido
- Sementes de Soja
- Sementes de Trigo
- Sementes de Arroz

**Aditivos (5):**
- Calcário Agrícola
- Enxofre
- Micronutrientes
- Gesso Agrícola
- Ácido Bórico

### Entradas de Estoque (20)
Cada matéria-prima tem pelo menos 1 entrada com:
- Quantidade
- Lote
- Data de entrada
- Data de vencimento
- Custo unitário
- Notas descritivas

### Movimentações (25)
- 10 entradas de estoque
- 15 saídas (processamento, venda, uso)

### Alertas (5)
- 4 alertas de estoque baixo
- 1 alerta crítico

---

## 🔧 Alternativas de Execução

### Opção 1: Usar MySQL Workbench
1. Abra MySQL Workbench
2. Conecte ao seu MySQL
3. Abra o arquivo `populate-database.sql`
4. Execute (Ctrl + Shift + Enter)

### Opção 2: Usar Linha de Comando
```bash
mysql -u root -p agroindustria_db < populate-database.sql
```

### Opção 3: Usar Node.js (seed.js)
```bash
npm run seed
```

---

## ✅ Verificar Dados Inseridos

Após executar o script, você verá:

```
Tabela                  Total
Usuários                5
Fornecedores            7
Matérias-Primas         20
Entradas de Estoque     20
Movimentações           25
Alertas                 5
```

---

## 🎯 O Que Fazer Agora

1. ✅ Execute o script SQL
2. ✅ Inicie o servidor (`npm start`)
3. ✅ Faça login com qualquer usuário
4. ✅ Explore o dashboard com dados completos
5. ✅ Teste todas as funcionalidades

---

## 💡 Dicas

- Os dados são realistas e baseados em operações reais de agroindústria
- Cada entrada tem notas descritivas
- Os alertas mostram estoque baixo/crítico
- As movimentações rastreiam entrada e saída
- Todos os dados estão relacionados corretamente

---

## 🆘 Troubleshooting

**Erro: "Unknown database"**
→ Crie o banco primeiro: `mysql -u root -p -e "CREATE DATABASE agroindustria_db CHARACTER SET utf8mb4;"`

**Erro: "Access denied"**
→ Verifique sua senha do MySQL

**Erro: "Foreign key constraint fails"**
→ Certifique-se de que as tabelas foram criadas pelo server.js antes de rodar o script

---

## 📞 Próximos Passos

1. Descompacte o arquivo
2. Configure a senha do MySQL no `.env`
3. Crie o banco de dados
4. Execute `npm install`
5. Execute o script SQL: `mysql -u root -p agroindustria_db < populate-database.sql`
6. Execute `npm start`
7. Acesse `http://localhost:3000`

---

**Tudo pronto com dados completos! 🎉**
